const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const root = __dirname;
const dbPath = path.join(root, "data", "db.json");
const port = Number(process.env.PORT || 4173);
const sockets = new Set();
let sessions = new Map();

const STATUS = new Set(["FREE", "RESERVED", "OCCUPIED", "MAINTENANCE"]);
const DEFAULT_SETTINGS = {
    default_checkout_offset_days: 1,
    default_checkout_hour: 14,
    default_checkout_minute: 0,
    log_retention_days: 3
};

function now() {
    return new Date().toISOString();
}

function id() {
    return crypto.randomUUID();
}

function passwordHash(password) {
    const salt = crypto.randomBytes(16).toString("hex");
    const hash = crypto.scryptSync(String(password), salt, 64).toString("hex");
    return `scrypt$${salt}$${hash}`;
}

function verifyPassword(password, stored) {
    const [scheme, salt, hash] = String(stored || "").split("$");
    if (scheme !== "scrypt" || !salt || !hash) return false;
    const actual = crypto.scryptSync(String(password), salt, 64);
    const expected = Buffer.from(hash, "hex");
    return expected.length === actual.length && crypto.timingSafeEqual(actual, expected);
}

function readDb() {
    const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));
    db.settings = { ...DEFAULT_SETTINGS, ...(db.settings || {}) };
    db.orders = db.orders || [];
    db.auditLogs = db.auditLogs || [];
    const retentionDays = Math.max(1, Number(db.settings.log_retention_days) || 3);
    const cutoff = new Date(Date.now() - retentionDays * 86400000).toISOString();
    db.auditLogs = db.auditLogs.filter(log => log.created_at >= cutoff);
    db.users = db.users || [];
    db.sessions = db.sessions || [];
    const now = Date.now();
    db.sessions = db.sessions.filter(s => s.expires_at > now);
    sessions = new Map(db.sessions.map(s => [s.token, { user_id: s.user_id, expires_at: s.expires_at }]));
    return db;
}

function writeDb(db) {
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
}

function persistSessions() {
    const db = JSON.parse(fs.readFileSync(dbPath, "utf8"));
    const now = Date.now();
    db.sessions = [...sessions.entries()]
        .filter(([, s]) => s.expires_at > now)
        .map(([token, s]) => ({ token, user_id: s.user_id, expires_at: s.expires_at }));
    fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
}

function json(res, status, payload) {
    res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(payload));
}

function setCookie(res, value) {
    res.setHeader("Set-Cookie", `ns_session=${value}; HttpOnly; Path=/; SameSite=Lax; Max-Age=86400`);
}

function clearCookie(res) {
    res.setHeader("Set-Cookie", "ns_session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0");
}

function parseCookies(req) {
    return Object.fromEntries(String(req.headers.cookie || "").split(";").map(item => {
        const index = item.indexOf("=");
        if (index === -1) return null;
        return [item.slice(0, index).trim(), decodeURIComponent(item.slice(index + 1).trim())];
    }).filter(Boolean));
}

function publicUser(user) {
    if (!user) return null;
    return { id: user.id, username: user.username, role: user.role, created_at: user.created_at, updated_at: user.updated_at };
}

function listUsers(db) {
    return db.users.map(publicUser).sort((a, b) => a.username.localeCompare(b.username, "zh-CN"));
}

function currentUser(req, db) {
    const token = parseCookies(req).ns_session;
    const session = token ? sessions.get(token) : null;
    if (!session || session.expires_at < Date.now()) {
        if (token) sessions.delete(token);
        return null;
    }
    const user = db.users.find(item => item.id === session.user_id);
    if (!user) {
        sessions.delete(token);
        return null;
    }
    return user;
}

function requireUser(req, db) {
    const user = currentUser(req, db);
    if (!user) {
        const error = new Error("请先登录");
        error.status = 401;
        throw error;
    }
    return user;
}

function requireAdmin(req, db) {
    const user = requireUser(req, db);
    if (user.role !== "ADMIN") {
        const error = new Error("需要管理员权限");
        error.status = 403;
        throw error;
    }
    return user;
}

function parseBody(req) {
    return new Promise((resolve, reject) => {
        let raw = "";
        req.on("data", chunk => {
            raw += chunk;
            if (raw.length > 1_000_000) reject(new Error("Payload too large"));
        });
        req.on("end", () => {
            if (!raw) return resolve({});
            try { resolve(JSON.parse(raw)); }
            catch { reject(new Error("Invalid JSON")); }
        });
        req.on("error", reject);
    });
}

function activeOrder(db, roomId) {
    return db.orders.find(order => order.room_id === roomId && order.status === "ACTIVE") || null;
}

function inventory(db, viewer = null) {
    const typeMap = new Map(db.roomTypes.map(type => [type.id, type]));
    const roomMap = new Map(db.rooms.map(room => [room.id, room]));
    const rooms = db.rooms.map(room => ({
        ...room,
        type: typeMap.get(room.type_id) || null,
        activeOrder: activeOrder(db, room.id)
    }));
    const roomTypes = db.roomTypes
        .slice()
        .sort((a, b) => Number(a.sort_order || 0) - Number(b.sort_order || 0))
        .map(type => ({
            ...type,
            rooms: rooms
                .filter(room => room.type_id === type.id)
                .sort((a, b) => Number(b.floor || 0) - Number(a.floor || 0) || a.room_number.localeCompare(b.room_number, "zh-CN", { numeric: true }))
        }));
    return {
        settings: { ...DEFAULT_SETTINGS, ...(db.settings || {}) },
        roomTypes,
        rooms,
        orders: viewer?.role === "ADMIN" ? db.orders
            .map(order => enrichOrder(db, order, roomMap, typeMap))
            .sort((a, b) => new Date(b.checkin_at || b.reservation_at || b.created_at) - new Date(a.checkin_at || a.reservation_at || a.created_at)) : [],
        auditLogs: viewer?.role === "ADMIN" ? db.auditLogs.slice().sort((a, b) => new Date(b.created_at) - new Date(a.created_at)) : [],
        users: viewer?.role === "ADMIN" ? listUsers(db) : [],
        currentUser: publicUser(viewer)
    };
}

function orderLogEntry(db, orderId, actions) {
    return db.auditLogs.find(log => actions.includes(log.action) && log.details?.order_id === orderId) || null;
}

function orderLogTime(db, orderId, actions) {
    return orderLogEntry(db, orderId, actions)?.created_at || null;
}

function enrichOrder(db, order, roomMap, typeMap) {
    const room = roomMap.get(order.room_id) || null;
    const type = room ? typeMap.get(room.type_id) : null;
    const reservationAt = order.reservation_at || (order.order_type === "RESERVATION" ? order.created_at : null);
    const checkinAt = order.checkin_at || orderLogTime(db, order.id, ["办理入住", "预订转入住"]) || (order.order_type === "WALK_IN" ? order.created_at : null);
    const checkoutAt = order.checkout_at || orderLogTime(db, order.id, ["退房结算"]) || (order.status === "COMPLETED" ? order.updated_at : null);
    const cancelledAt = order.cancelled_at || orderLogTime(db, order.id, ["取消预订"]) || (order.status === "CANCELLED" ? order.updated_at : null);
    const creator = orderLogEntry(db, order.id, ["办理入住", "新建预订", "预订转入住"]);
    return {
        ...order,
        room_number: room?.room_number || "-",
        room_type_name: type?.name || "未配置房型",
        has_reservation: order.order_type === "RESERVATION",
        reservation_at: reservationAt,
        checkin_at: checkinAt,
        checkout_at: checkoutAt,
        cancelled_at: cancelledAt,
        operator: creator?.user || null,
        reservation_guest_name: order.reservation_guest_name ?? (order.order_type === "RESERVATION" ? order.guest_name : null),
        reservation_phone: order.reservation_phone ?? (order.order_type === "RESERVATION" ? order.phone : null),
        reservation_expected_checkout: order.reservation_expected_checkout ?? (order.order_type === "RESERVATION" ? order.expected_checkout : null)
    };
}

function log(db, room, action, details = {}, user = "system") {
    db.auditLogs.push({
        id: id(),
        user,
        room_number: room?.room_number || null,
        action,
        details,
        created_at: now()
    });
}

function broadcast(payload) {
    const frame = websocketFrame(JSON.stringify(payload));
    for (const socket of sockets) {
        if (!socket.destroyed) socket.write(frame);
    }
}

function websocketFrame(text) {
    const payload = Buffer.from(text);
    const header = [];
    header.push(0x81);
    if (payload.length < 126) {
        header.push(payload.length);
    } else if (payload.length < 65536) {
        header.push(126, (payload.length >> 8) & 255, payload.length & 255);
    } else {
        header.push(127, 0, 0, 0, 0, (payload.length >> 24) & 255, (payload.length >> 16) & 255, (payload.length >> 8) & 255, payload.length & 255);
    }
    return Buffer.concat([Buffer.from(header), payload]);
}

function validateRoomType(payload) {
    if (!payload.name || !String(payload.name).trim()) throw new Error("房型名称不能为空");
    return {
        name: String(payload.name).trim(),
        description: String(payload.description || "").trim(),
        sort_order: Number(payload.sort_order || 100)
    };
}

function validateRoom(payload, db) {
    if (!payload.room_number || !String(payload.room_number).trim()) throw new Error("房号不能为空");
    if (!db.roomTypes.some(type => type.id === payload.type_id)) throw new Error("请选择有效房型");
    const roomNumber = String(payload.room_number).trim();
    const floor = Number(payload.floor || roomNumber.charAt(0));
    if (!Number.isFinite(floor)) throw new Error("楼层必须是数字");
    return { room_number: roomNumber, floor, type_id: payload.type_id };
}

function validateSettings(payload) {
    const settings = {
        default_checkout_offset_days: Number(payload.default_checkout_offset_days ?? DEFAULT_SETTINGS.default_checkout_offset_days),
        default_checkout_hour: Number(payload.default_checkout_hour ?? DEFAULT_SETTINGS.default_checkout_hour),
        default_checkout_minute: Number(payload.default_checkout_minute ?? DEFAULT_SETTINGS.default_checkout_minute),
        log_retention_days: Number(payload.log_retention_days ?? DEFAULT_SETTINGS.log_retention_days)
    };
    if (!Number.isInteger(settings.default_checkout_offset_days) || settings.default_checkout_offset_days < 0 || settings.default_checkout_offset_days > 30) {
        throw new Error("默认退房偏移天数必须是 0-30 的整数");
    }
    if (!Number.isInteger(settings.default_checkout_hour) || settings.default_checkout_hour < 0 || settings.default_checkout_hour > 23) {
        throw new Error("默认退房小时必须是 0-23 的整数");
    }
    if (!Number.isInteger(settings.default_checkout_minute) || settings.default_checkout_minute < 0 || settings.default_checkout_minute > 59) {
        throw new Error("默认退房分钟必须是 0-59 的整数");
    }
    if (!Number.isInteger(settings.log_retention_days) || settings.log_retention_days < 1 || settings.log_retention_days > 365) {
        throw new Error("日志保留天数必须是 1-365 的整数，禁止设为 0");
    }
    return settings;
}

function validateUserPayload(payload, existing = null) {
    const username = String(payload.username ?? existing?.username ?? "").trim();
    const role = String(payload.role ?? existing?.role ?? "STAFF").trim().toUpperCase();
    const password = payload.password == null ? "" : String(payload.password);
    if (!username) throw new Error("账号名称不能为空");
    if (!["ADMIN", "STAFF"].includes(role)) throw new Error("账号权限无效");
    if (!existing && password.length < 6) throw new Error("新账号密码至少 6 位");
    if (existing && password && password.length < 6) throw new Error("新密码至少 6 位");
    return { username, role, password };
}

function money(value) {
    const number = Number(value || 0);
    return Number.isFinite(number) && number > 0 ? number : 0;
}

function guestInfo(payload = {}) {
    return {
        guest_name: payload.guest_name ? String(payload.guest_name).trim() : null,
        phone: payload.phone ? String(payload.phone).trim() : null,
        expected_checkout: payload.expected_checkout ? String(payload.expected_checkout) : null,
        deposit: money(payload.deposit)
    };
}

function mutateRoomAction(db, roomId, actionType, rawGuestInfo, actor) {
    const room = db.rooms.find(item => item.id === roomId);
    if (!room) throw new Error("房间不存在");

    const guest = guestInfo(rawGuestInfo);
    const currentOrder = activeOrder(db, room.id);

    if (actionType === "CHECK_IN") {
        if (room.status !== "FREE") throw new Error("只有空闲房可以直接入住");
        const stamp = now();
        const order = { id: id(), room_id: room.id, ...guest, order_type: "WALK_IN", status: "ACTIVE", checkin_at: stamp, created_at: stamp, updated_at: stamp };
        db.orders.push(order);
        room.status = "OCCUPIED";
        log(db, room, "办理入住", { order_id: order.id, deposit: order.deposit, anonymous: !order.guest_name }, actor.username);
    } else if (actionType === "RESERVE") {
        if (room.status !== "FREE") throw new Error("只有空闲房可以新建预订");
        const stamp = now();
        const order = {
            id: id(),
            room_id: room.id,
            ...guest,
            reservation_guest_name: guest.guest_name,
            reservation_phone: guest.phone,
            reservation_expected_checkout: guest.expected_checkout,
            order_type: "RESERVATION",
            status: "ACTIVE",
            reservation_at: stamp,
            created_at: stamp,
            updated_at: stamp
        };
        db.orders.push(order);
        room.status = "RESERVED";
        log(db, room, "新建预订", { order_id: order.id, anonymous: !order.guest_name }, actor.username);
    } else if (actionType === "CONVERT_TO_CHECK_IN") {
        if (room.status !== "RESERVED" || !currentOrder) throw new Error("没有可转入住的有效预订");
        const stamp = now();
        Object.assign(currentOrder, {
            guest_name: guest.guest_name || currentOrder.guest_name,
            phone: guest.phone || currentOrder.phone,
            expected_checkout: guest.expected_checkout || currentOrder.expected_checkout,
            deposit: guest.deposit || currentOrder.deposit || 0,
            checkin_at: stamp,
            updated_at: stamp
        });
        room.status = "OCCUPIED";
        log(db, room, "预订转入住", { order_id: currentOrder.id, deposit: currentOrder.deposit }, actor.username);
    } else if (actionType === "CANCEL_RESERVATION") {
        if (room.status !== "RESERVED" || !currentOrder) throw new Error("没有可取消的有效预订");
        const stamp = now();
        currentOrder.status = "CANCELLED";
        currentOrder.cancelled_at = stamp;
        currentOrder.updated_at = stamp;
        room.status = "FREE";
        log(db, room, "取消预订", { order_id: currentOrder.id }, actor.username);
    } else if (actionType === "CHECK_OUT") {
        if (room.status !== "OCCUPIED" || !currentOrder) throw new Error("没有可退房的有效入住客单");
        const stamp = now();
        currentOrder.status = "COMPLETED";
        currentOrder.checkout_at = stamp;
        currentOrder.updated_at = stamp;
        room.status = "MAINTENANCE";
        log(db, room, "退房结算", { order_id: currentOrder.id, deposit_refund: currentOrder.deposit || 0 }, actor.username);
    } else if (actionType === "CLEAN_DONE") {
        if (room.status !== "MAINTENANCE") throw new Error("只有维修/打扫房可以释放");
        room.status = "FREE";
        log(db, room, "打扫完成", {}, actor.username);
    } else {
        throw new Error("未知动作类型");
    }
}

async function handleApi(req, res, url) {
    try {
        const db = readDb();
        const method = req.method;
        const parts = url.pathname.split("/").filter(Boolean);

        if (method === "GET" && url.pathname === "/api/auth/me") {
            return json(res, 200, { user: publicUser(currentUser(req, db)), needsSetup: db.users.length === 0 });
        }

        if (method === "POST" && url.pathname === "/api/setup") {
            if (db.users.length > 0) return json(res, 400, { error: "系统已初始化，不能重复设置" });
            const payload = validateUserPayload(await parseBody(req));
            const user = {
                id: id(),
                username: payload.username,
                role: "ADMIN",
                password_hash: passwordHash(payload.password),
                created_at: now(),
                updated_at: now()
            };
            db.users.push(user);
            writeDb(db);
            const token = crypto.randomBytes(32).toString("hex");
            sessions.set(token, { user_id: user.id, expires_at: Date.now() + 24 * 60 * 60 * 1000 });
            persistSessions();
            setCookie(res, token);
            return json(res, 201, { user: publicUser(user) });
        }

        if (method === "POST" && url.pathname === "/api/auth/login") {
            const payload = await parseBody(req);
            const user = db.users.find(item => item.username === String(payload.username || "").trim());
            if (!user || !verifyPassword(payload.password || "", user.password_hash)) {
                return json(res, 401, { error: "账号或密码错误" });
            }
            const token = crypto.randomBytes(32).toString("hex");
            sessions.set(token, { user_id: user.id, expires_at: Date.now() + 24 * 60 * 60 * 1000 });
            persistSessions();
            setCookie(res, token);
            return json(res, 200, { user: publicUser(user) });
        }

        if (method === "POST" && url.pathname === "/api/auth/logout") {
            const token = parseCookies(req).ns_session;
            if (token) sessions.delete(token);
            persistSessions();
            clearCookie(res);
            return json(res, 200, { ok: true });
        }

        const actor = requireUser(req, db);

        if (method === "GET" && url.pathname === "/api/inventory") return json(res, 200, inventory(db, actor));

        if (method === "PATCH" && url.pathname === "/api/settings") {
            requireAdmin(req, db);
            db.settings = validateSettings({ ...db.settings, ...(await parseBody(req)) });
            writeDb(db);
            broadcast({ type: "inventory_changed" });
            return json(res, 200, inventory(db, actor));
        }

        if (method === "POST" && url.pathname === "/api/users") {
            requireAdmin(req, db);
            const payload = validateUserPayload(await parseBody(req));
            if (db.users.some(user => user.username === payload.username)) throw new Error("账号名称已存在");
            db.users.push({
                id: id(),
                username: payload.username,
                role: payload.role,
                password_hash: passwordHash(payload.password),
                created_at: now(),
                updated_at: now()
            });
            writeDb(db);
            return json(res, 201, { users: listUsers(db) });
        }

        if (parts[1] === "users" && parts[2]) {
            requireAdmin(req, db);
            const target = db.users.find(user => user.id === parts[2]);
            if (!target) return json(res, 404, { error: "账号不存在" });
            if (method === "PATCH") {
                const payload = validateUserPayload(await parseBody(req), target);
                if (db.users.some(user => user.id !== target.id && user.username === payload.username)) throw new Error("账号名称已存在");
                const adminCount = db.users.filter(user => user.role === "ADMIN").length;
                if (target.role === "ADMIN" && payload.role !== "ADMIN" && adminCount <= 1) throw new Error("至少保留一个管理员账号");
                target.username = payload.username;
                target.role = payload.role;
                if (payload.password) target.password_hash = passwordHash(payload.password);
                target.updated_at = now();
                writeDb(db);
                return json(res, 200, { users: listUsers(db), currentUser: publicUser(db.users.find(user => user.id === actor.id)) });
            }
            if (method === "DELETE") {
                const adminCount = db.users.filter(user => user.role === "ADMIN").length;
                if (target.role === "ADMIN" && adminCount <= 1) throw new Error("至少保留一个管理员账号");
                db.users = db.users.filter(user => user.id !== target.id);
                writeDb(db);
                return json(res, 200, { users: listUsers(db) });
            }
        }

        if (method === "POST" && url.pathname === "/api/room-types") {
            requireAdmin(req, db);
            const payload = validateRoomType(await parseBody(req));
            db.roomTypes.push({ id: id(), ...payload });
            writeDb(db);
            broadcast({ type: "inventory_changed" });
            return json(res, 201, inventory(db, actor));
        }

        if (parts[1] === "room-types" && parts[2]) {
            requireAdmin(req, db);
            const type = db.roomTypes.find(item => item.id === parts[2]);
            if (!type) return json(res, 404, { error: "房型不存在" });
            if (method === "PATCH") {
                Object.assign(type, validateRoomType({ ...type, ...(await parseBody(req)) }));
                writeDb(db);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, inventory(db, actor));
            }
            if (method === "DELETE") {
                if (db.rooms.some(room => room.type_id === type.id)) throw new Error("该房型下仍有房间，不能删除");
                db.roomTypes = db.roomTypes.filter(item => item.id !== type.id);
                writeDb(db);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, inventory(db, actor));
            }
        }

        if (method === "POST" && url.pathname === "/api/rooms") {
            requireAdmin(req, db);
            const payload = validateRoom(await parseBody(req), db);
            if (db.rooms.some(room => room.room_number === payload.room_number)) throw new Error("房号已存在");
            const room = { id: id(), ...payload, status: "FREE" };
            db.rooms.push(room);
            log(db, room, "新增房间", { type_id: room.type_id }, actor.username);
            writeDb(db);
            broadcast({ type: "inventory_changed" });
            return json(res, 201, inventory(db, actor));
        }

        if (method === "POST" && url.pathname === "/api/rooms/bulk") {
            requireAdmin(req, db);
            const payload = await parseBody(req);
            if (!db.roomTypes.some(type => type.id === payload.type_id)) throw new Error("请选择有效房型");
            const start = Number(payload.start);
            const end = Number(payload.end);
            const floor = Number(payload.floor || String(payload.start).charAt(0));
            if (!Number.isInteger(start) || !Number.isInteger(end) || end < start) throw new Error("请输入有效的连续房号");
            for (let roomNumber = start; roomNumber <= end; roomNumber += 1) {
                const room_number = String(roomNumber);
                if (!db.rooms.some(room => room.room_number === room_number)) {
                    const room = { id: id(), room_number, floor, type_id: payload.type_id, status: "FREE" };
                    db.rooms.push(room);
                    log(db, room, "新增房间", { type_id: room.type_id, bulk: true }, actor.username);
                }
            }
            writeDb(db);
            broadcast({ type: "inventory_changed" });
            return json(res, 201, inventory(db, actor));
        }

        if (parts[1] === "rooms" && parts[2]) {
            const room = db.rooms.find(item => item.id === parts[2]);
            if (!room) return json(res, 404, { error: "房间不存在" });
            if (method === "POST" && parts[3] === "action") {
                const payload = await parseBody(req);
                mutateRoomAction(db, room.id, payload.actionType, payload.guestInfo, actor);
                writeDb(db);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, inventory(db, actor));
            }
            if (method === "PATCH") {
                requireAdmin(req, db);
                const payload = validateRoom({ ...room, ...(await parseBody(req)) }, db);
                if (db.rooms.some(item => item.id !== room.id && item.room_number === payload.room_number)) throw new Error("房号已存在");
                Object.assign(room, payload);
                log(db, room, "修改房间", { type_id: room.type_id, floor: room.floor }, actor.username);
                writeDb(db);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, inventory(db, actor));
            }
            if (method === "DELETE") {
                requireAdmin(req, db);
                if (STATUS.has(room.status) && room.status !== "FREE") throw new Error("只能删除空闲房间");
                db.rooms = db.rooms.filter(item => item.id !== room.id);
                log(db, room, "删除房间", {}, actor.username);
                writeDb(db);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, inventory(db, actor));
            }
        }

        if (parts[1] === "orders" && parts[2]) {
            requireAdmin(req, db);
            const order = db.orders.find(item => item.id === parts[2]);
            if (!order) return json(res, 404, { error: "订单不存在" });
            if (method === "DELETE") {
                const room = db.rooms.find(r => r.id === order.room_id);
                if (order.status === "ACTIVE") throw new Error("不能删除进行中的订单，请先退房或取消");
                db.orders = db.orders.filter(item => item.id !== order.id);
                log(db, room, "删除订单", { order_id: order.id, guest_name: order.guest_name }, actor.username);
                writeDb(db);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, inventory(db, actor));
            }
        }

        json(res, 404, { error: "API 不存在" });
    } catch (err) {
        json(res, err.status || 400, { error: err.message });
    }
}

function serveStatic(req, res, url) {
    const filePath = url.pathname === "/" || url.pathname === "/admin"
        ? path.join(root, "index.html")
        : path.join(root, decodeURIComponent(url.pathname));
    if (!filePath.startsWith(root)) {
        res.writeHead(403);
        return res.end("Forbidden");
    }
    fs.readFile(filePath, (err, content) => {
        if (err) {
            res.writeHead(404);
            return res.end("Not found");
        }
        const ext = path.extname(filePath);
        const type = ext === ".html" ? "text/html; charset=utf-8" : "application/octet-stream";
        res.writeHead(200, { "Content-Type": type });
        res.end(content);
    });
}

const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname.startsWith("/api/")) return handleApi(req, res, url);
    serveStatic(req, res, url);
});

server.on("upgrade", (req, socket) => {
    if (req.url !== "/ws/rooms") return socket.destroy();
    const db = readDb();
    if (!currentUser(req, db)) return socket.destroy();
    const key = req.headers["sec-websocket-key"];
    const accept = crypto.createHash("sha1").update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`).digest("base64");
    socket.write([
        "HTTP/1.1 101 Switching Protocols",
        "Upgrade: websocket",
        "Connection: Upgrade",
        `Sec-WebSocket-Accept: ${accept}`,
        "",
        ""
    ].join("\r\n"));
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
    socket.on("error", () => sockets.delete(socket));
});

server.listen(port, () => {
    console.log(`NexusStay OS running at http://localhost:${port}`);
});
