const mysql = require("mysql2/promise");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const root = __dirname;
const configPath = path.join(root, "data", "config.json");
const lockPath = path.join(root, "data", "install.lock");

let pool = null;

function isInstalled() {
    return fs.existsSync(lockPath) && fs.existsSync(configPath);
}

function loadConfig() {
    if (!fs.existsSync(configPath)) return null;
    return JSON.parse(fs.readFileSync(configPath, "utf8"));
}

function createPool(config) {
    return mysql.createPool({
        host: config.host || "127.0.0.1",
        port: Number(config.port || 3306),
        user: config.user || "root",
        password: config.password || "",
        database: config.database || "nexusstay",
        charset: "utf8mb4",
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0
    });
}

function getPool() {
    return pool;
}

function initFromConfig() {
    const config = loadConfig();
    if (!config) return null;
    pool = createPool(config);
    return pool;
}

async function testConnection(config) {
    const testPool = mysql.createPool({
        host: config.host || "127.0.0.1",
        port: Number(config.port || 3306),
        user: config.user || "root",
        password: config.password || "",
        database: config.database || "nexusstay",
        charset: "utf8mb4",
        waitForConnections: true,
        connectionLimit: 1
    });
    try {
        const conn = await testPool.getConnection();
        conn.release();
        await testPool.end();
        return { ok: true };
    } catch (e) {
        await testPool.end().catch(() => {});
        return { ok: false, error: e.message };
    }
}

async function runInstall(dbConfig, adminUser) {
    // Create pool with user's config
    const installPool = mysql.createPool({
        host: dbConfig.host || "127.0.0.1",
        port: Number(dbConfig.port || 3306),
        user: dbConfig.user || "root",
        password: dbConfig.password || "",
        database: dbConfig.database || "nexusstay",
        charset: "utf8mb4",
        waitForConnections: true,
        connectionLimit: 2
    });

    const conn = await installPool.getConnection();
    try {
        // Create tables
        await conn.query(`
            CREATE TABLE IF NOT EXISTS settings (
                \`key\` VARCHAR(100) NOT NULL PRIMARY KEY,
                \`value\` VARCHAR(255) NOT NULL DEFAULT ''
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);
        await conn.query(`
            CREATE TABLE IF NOT EXISTS room_types (
                id VARCHAR(36) NOT NULL PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                description VARCHAR(255) NOT NULL DEFAULT '',
                sort_order INT NOT NULL DEFAULT 100
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);
        await conn.query(`
            CREATE TABLE IF NOT EXISTS rooms (
                id VARCHAR(36) NOT NULL PRIMARY KEY,
                room_number VARCHAR(20) NOT NULL,
                floor INT NOT NULL DEFAULT 0,
                type_id VARCHAR(36) NOT NULL,
                status ENUM('FREE','RESERVED','OCCUPIED','MAINTENANCE') NOT NULL DEFAULT 'FREE',
                UNIQUE KEY uk_room_number (room_number),
                KEY idx_type_id (type_id),
                KEY idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);
        await conn.query(`
            CREATE TABLE IF NOT EXISTS orders (
                id VARCHAR(36) NOT NULL PRIMARY KEY,
                room_id VARCHAR(36) NOT NULL,
                guest_name VARCHAR(100) DEFAULT NULL,
                phone VARCHAR(50) DEFAULT NULL,
                expected_checkout VARCHAR(30) DEFAULT NULL,
                deposit DECIMAL(10,2) NOT NULL DEFAULT 0,
                order_type ENUM('WALK_IN','RESERVATION') NOT NULL,
                status ENUM('ACTIVE','COMPLETED','CANCELLED') NOT NULL DEFAULT 'ACTIVE',
                reservation_at DATETIME DEFAULT NULL,
                checkin_at DATETIME DEFAULT NULL,
                checkout_at DATETIME DEFAULT NULL,
                cancelled_at DATETIME DEFAULT NULL,
                reservation_guest_name VARCHAR(100) DEFAULT NULL,
                reservation_phone VARCHAR(50) DEFAULT NULL,
                reservation_expected_checkout VARCHAR(30) DEFAULT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                KEY idx_room_id (room_id),
                KEY idx_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);
        await conn.query(`
            CREATE TABLE IF NOT EXISTS users (
                id VARCHAR(36) NOT NULL PRIMARY KEY,
                username VARCHAR(100) NOT NULL,
                role ENUM('ADMIN','STAFF') NOT NULL DEFAULT 'STAFF',
                password_hash VARCHAR(255) NOT NULL,
                created_at DATETIME NOT NULL,
                updated_at DATETIME NOT NULL,
                UNIQUE KEY uk_username (username)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);
        await conn.query(`
            CREATE TABLE IF NOT EXISTS sessions (
                token VARCHAR(64) NOT NULL PRIMARY KEY,
                user_id VARCHAR(36) NOT NULL,
                expires_at BIGINT NOT NULL,
                KEY idx_user_id (user_id),
                KEY idx_expires_at (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);
        await conn.query(`
            CREATE TABLE IF NOT EXISTS audit_logs (
                id VARCHAR(36) NOT NULL PRIMARY KEY,
                user VARCHAR(100) NOT NULL DEFAULT 'system',
                room_number VARCHAR(20) DEFAULT NULL,
                action VARCHAR(100) NOT NULL,
                details JSON DEFAULT NULL,
                created_at DATETIME NOT NULL,
                KEY idx_created_at (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        `);

        // Insert default settings
        const defaults = {
            default_checkout_offset_days: "1",
            default_checkout_hour: "14",
            default_checkout_minute: "0",
            log_retention_days: "3"
        };
        for (const [key, value] of Object.entries(defaults)) {
            await conn.query("INSERT IGNORE INTO settings (`key`, `value`) VALUES (?, ?)", [key, value]);
        }

        // Create admin user
        const salt = crypto.randomBytes(16).toString("hex");
        const hash = crypto.scryptSync(String(adminUser.password), salt, 64).toString("hex");
        const passwordHash = `scrypt$${salt}$${hash}`;
        const stamp = new Date().toISOString().replace("T", " ").slice(0, 19);
        const userId = crypto.randomUUID();
        await conn.query(
            "INSERT INTO users (id, username, role, password_hash, created_at, updated_at) VALUES (?,?,?,?,?,?)",
            [userId, adminUser.username, "ADMIN", passwordHash, stamp, stamp]
        );

        // Write config file
        const dataDir = path.join(root, "data");
        if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
        fs.writeFileSync(configPath, JSON.stringify(dbConfig, null, 2));

        // Write lock file
        fs.writeFileSync(lockPath, JSON.stringify({ installed_at: stamp, admin: adminUser.username }));

        // Set the pool for immediate use
        pool = installPool;

        return { ok: true };
    } catch (e) {
        await conn.rollback().catch(() => {});
        throw e;
    } finally {
        conn.release();
    }
}

// Settings helpers (used by server.js after install)
const DEFAULT_SETTINGS = {
    default_checkout_offset_days: 1,
    default_checkout_hour: 14,
    default_checkout_minute: 0,
    log_retention_days: 3
};

async function getSettings() {
    const [rows] = await pool.query("SELECT `key`, `value` FROM settings");
    const settings = {};
    for (const row of rows) settings[row.key] = row.value;
    return {
        default_checkout_offset_days: Number(settings.default_checkout_offset_days ?? 1),
        default_checkout_hour: Number(settings.default_checkout_hour ?? 14),
        default_checkout_minute: Number(settings.default_checkout_minute ?? 0),
        log_retention_days: Number(settings.log_retention_days ?? 3)
    };
}

async function saveSettings(settings) {
    for (const [key, value] of Object.entries(settings)) {
        await pool.query(
            "INSERT INTO settings (`key`, `value`) VALUES (?, ?) ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)",
            [key, String(value)]
        );
    }
}

async function cleanOldLogs() {
    const settings = await getSettings();
    const days = Math.max(1, settings.log_retention_days || 3);
    const [result] = await pool.query("DELETE FROM audit_logs WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)", [days]);
    if (result.affectedRows > 0) {
        console.log(`Cleaned ${result.affectedRows} audit log(s) older than ${days} days`);
    }
}

async function loadSessions() {
    await pool.query("DELETE FROM sessions WHERE expires_at < ?", [Date.now()]);
    const [rows] = await pool.query("SELECT token, user_id, expires_at FROM sessions");
    const map = new Map();
    for (const row of rows) map.set(row.token, { user_id: row.user_id, expires_at: Number(row.expires_at) });
    return map;
}

module.exports = {
    isInstalled, loadConfig, createPool, getPool, initFromConfig,
    testConnection, runInstall,
    getSettings, saveSettings, cleanOldLogs, loadSessions,
    DEFAULT_SETTINGS
};
