const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const db = require("./db");

const root = __dirname;
const port = Number(process.env.PORT || 4173);
const sockets = new Set();
let sessions = new Map();
let installed = db.isInstalled();
let pool = null;

const DEFAULT_SETTINGS = db.DEFAULT_SETTINGS;

function getSettings() { return db.getSettings(); }
function saveSettings(s) { return db.saveSettings(s); }

const STATUS = new Set(["FREE", "RESERVED", "OCCUPIED", "MAINTENANCE"]);

function now() {
    return new Date().toISOString().replace("T", " ").slice(0, 19);
}

function id() {
    return crypto.randomUUID();
}

function passwordHash(password) {
    const salt = crypto.randomBytes(16).toString("hex");
    const hash = crypto.scryptSync(String(password), salt, 64).toString("hex");
    return `scrypt$${salt}$${hash}`;
}

function verifyPassword(password, stored) {
    const [scheme, salt, hash] = String(stored || "").split("$");
    if (scheme !== "scrypt" || !salt || !hash) return false;
    const actual = crypto.scryptSync(String(password), salt, 64);
    const expected = Buffer.from(hash, "hex");
    return expected.length === actual.length && crypto.timingSafeEqual(actual, expected);
}

function json(res, status, payload) {
    res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
    res.end(JSON.stringify(payload));
}

function setCookie(res, value) {
    res.setHeader("Set-Cookie", `ns_session=${value}; HttpOnly; Path=/; SameSite=Lax; Max-Age=86400`);
}

function clearCookie(res) {
    res.setHeader("Set-Cookie", "ns_session=; HttpOnly; Path=/; SameSite=Lax; Max-Age=0");
}

function parseCookies(req) {
    return Object.fromEntries(String(req.headers.cookie || "").split(";").map(item => {
        const index = item.indexOf("=");
        if (index === -1) return null;
        return [item.slice(0, index).trim(), decodeURIComponent(item.slice(index + 1).trim())];
    }).filter(Boolean));
}

function publicUser(user) {
    if (!user) return null;
    return { id: user.id, username: user.username, role: user.role, created_at: user.created_at, updated_at: user.updated_at };
}

function parseBody(req) {
    return new Promise((resolve, reject) => {
        let raw = "";
        req.on("data", chunk => {
            raw += chunk;
            if (raw.length > 1_000_000) reject(new Error("Payload too large"));
        });
        req.on("end", () => {
            if (!raw) return resolve({});
            try { resolve(JSON.parse(raw)); }
            catch { reject(new Error("Invalid JSON")); }
        });
        req.on("error", reject);
    });
}

// ── Auth helpers ──

async function currentUser(req) {
    const token = parseCookies(req).ns_session;
    const session = token ? sessions.get(token) : null;
    if (!session || session.expires_at < Date.now()) {
        if (token) {
            sessions.delete(token);
            await pool.query("DELETE FROM sessions WHERE token = ?", [token]).catch(() => {});
        }
        return null;
    }
    const [rows] = await pool.query("SELECT * FROM users WHERE id = ?", [session.user_id]);
    if (!rows.length) {
        sessions.delete(token);
        await pool.query("DELETE FROM sessions WHERE token = ?", [token]).catch(() => {});
        return null;
    }
    return rows[0];
}

async function requireUser(req) {
    const user = await currentUser(req);
    if (!user) {
        const error = new Error("请先登录");
        error.status = 401;
        throw error;
    }
    return user;
}

async function requireAdmin(req) {
    const user = await requireUser(req);
    if (user.role !== "ADMIN") {
        const error = new Error("需要管理员权限");
        error.status = 403;
        throw error;
    }
    return user;
}

async function saveSession(token, userId) {
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000;
    sessions.set(token, { user_id: userId, expires_at: expiresAt });
    await pool.query("INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)", [token, userId, expiresAt]);
}

async function deleteSession(token) {
    sessions.delete(token);
    await pool.query("DELETE FROM sessions WHERE token = ?", [token]).catch(() => {});
}

// ── Audit log ──

async function writeLog(roomNumber, action, details, username) {
    await pool.query(
        "INSERT INTO audit_logs (id, user, room_number, action, details, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        [id(), username || "system", roomNumber || null, action, JSON.stringify(details || {}), now()]
    );
}

// ── Validation ──

function validateRoomType(payload) {
    if (!payload.name || !String(payload.name).trim()) throw new Error("房型名称不能为空");
    return {
        name: String(payload.name).trim(),
        description: String(payload.description || "").trim(),
        sort_order: Number(payload.sort_order || 100)
    };
}

function validateRoom(payload) {
    if (!payload.room_number || !String(payload.room_number).trim()) throw new Error("房号不能为空");
    const roomNumber = String(payload.room_number).trim();
    const floor = Number(payload.floor || roomNumber.charAt(0));
    if (!Number.isFinite(floor)) throw new Error("楼层必须是数字");
    return { room_number: roomNumber, floor, type_id: payload.type_id };
}

function validateSettings(payload) {
    const settings = {
        default_checkout_offset_days: Number(payload.default_checkout_offset_days ?? DEFAULT_SETTINGS.default_checkout_offset_days),
        default_checkout_hour: Number(payload.default_checkout_hour ?? DEFAULT_SETTINGS.default_checkout_hour),
        default_checkout_minute: Number(payload.default_checkout_minute ?? DEFAULT_SETTINGS.default_checkout_minute),
        log_retention_days: Number(payload.log_retention_days ?? DEFAULT_SETTINGS.log_retention_days)
    };
    if (!Number.isInteger(settings.default_checkout_offset_days) || settings.default_checkout_offset_days < 0 || settings.default_checkout_offset_days > 30) {
        throw new Error("默认退房偏移天数必须是 0-30 的整数");
    }
    if (!Number.isInteger(settings.default_checkout_hour) || settings.default_checkout_hour < 0 || settings.default_checkout_hour > 23) {
        throw new Error("默认退房小时必须是 0-23 的整数");
    }
    if (!Number.isInteger(settings.default_checkout_minute) || settings.default_checkout_minute < 0 || settings.default_checkout_minute > 59) {
        throw new Error("默认退房分钟必须是 0-59 的整数");
    }
    if (!Number.isInteger(settings.log_retention_days) || settings.log_retention_days < 1 || settings.log_retention_days > 365) {
        throw new Error("日志保留天数必须是 1-365 的整数，禁止设为 0");
    }
    return settings;
}

function validateUserPayload(payload, existing = null) {
    const username = String(payload.username ?? existing?.username ?? "").trim();
    const role = String(payload.role ?? existing?.role ?? "STAFF").trim().toUpperCase();
    const password = payload.password == null ? "" : String(payload.password);
    if (!username) throw new Error("账号名称不能为空");
    if (!["ADMIN", "STAFF"].includes(role)) throw new Error("账号权限无效");
    if (!existing && password.length < 6) throw new Error("新账号密码至少 6 位");
    if (existing && password && password.length < 6) throw new Error("新密码至少 6 位");
    return { username, role, password };
}

function money(value) {
    const number = Number(value || 0);
    return Number.isFinite(number) && number > 0 ? number : 0;
}

function guestInfo(payload = {}) {
    return {
        guest_name: payload.guest_name ? String(payload.guest_name).trim() : null,
        phone: payload.phone ? String(payload.phone).trim() : null,
        expected_checkout: payload.expected_checkout ? String(payload.expected_checkout) : null,
        deposit: money(payload.deposit)
    };
}

// ── Inventory (full data for frontend) ──

async function inventory(viewer = null) {
    const [settings] = await getSettings().then(s => [s]);
    const [roomTypes] = await pool.query("SELECT * FROM room_types ORDER BY sort_order");
    const [roomsRaw] = await pool.query("SELECT * FROM rooms ORDER BY floor DESC, room_number");
    const [activeOrders] = await pool.query("SELECT * FROM orders WHERE status = 'ACTIVE'");

    const orderMap = new Map();
    for (const o of activeOrders) orderMap.set(o.room_id, o);

    const rooms = roomsRaw.map(room => ({
        ...room,
        type: roomTypes.find(t => t.id === room.type_id) || null,
        activeOrder: orderMap.get(room.id) || null
    }));

    const roomTypesOut = roomTypes.map(type => ({
        ...type,
        rooms: rooms.filter(r => r.type_id === type.id)
    }));

    const result = { settings: { ...DEFAULT_SETTINGS, ...settings }, roomTypes: roomTypesOut, rooms, orders: [], auditLogs: [], users: [], currentUser: publicUser(viewer) };

    if (viewer?.role === "ADMIN") {
        const [ordersRaw] = await pool.query(`
            SELECT o.*, r.room_number, rt.name as room_type_name
            FROM orders o
            LEFT JOIN rooms r ON o.room_id = r.id
            LEFT JOIN room_types rt ON r.type_id = rt.id
            ORDER BY COALESCE(o.checkin_at, o.reservation_at, o.created_at) DESC
        `);

        // Enrich orders with audit log data
        const [logs] = await pool.query("SELECT * FROM audit_logs ORDER BY created_at DESC");
        const logByOrder = new Map();
        for (const log of logs) {
            const oid = log.details?.order_id;
            if (!oid) continue;
            if (!logByOrder.has(oid)) logByOrder.set(oid, []);
            logByOrder.get(oid).push(log);
        }

        result.orders = ordersRaw.map(order => {
            const oLogs = logByOrder.get(order.id) || [];
            const findLog = (actions) => oLogs.find(l => actions.includes(l.action));
            const creator = findLog(["办理入住", "新建预订", "预订转入住"]);
            const reservationAt = order.reservation_at || (order.order_type === "RESERVATION" ? order.created_at : null);
            const checkinAt = order.checkin_at || findLog(["办理入住", "预订转入住"])?.created_at || (order.order_type === "WALK_IN" ? order.created_at : null);
            const checkoutAt = order.checkout_at || findLog(["退房结算"])?.created_at || (order.status === "COMPLETED" ? order.updated_at : null);
            const cancelledAt = order.cancelled_at || findLog(["取消预订"])?.created_at || (order.status === "CANCELLED" ? order.updated_at : null);
            return {
                ...order,
                has_reservation: order.order_type === "RESERVATION",
                reservation_at: reservationAt,
                checkin_at: checkinAt,
                checkout_at: checkoutAt,
                cancelled_at: cancelledAt,
                operator: creator?.user || null,
                reservation_guest_name: order.reservation_guest_name ?? (order.order_type === "RESERVATION" ? order.guest_name : null),
                reservation_phone: order.reservation_phone ?? (order.order_type === "RESERVATION" ? order.phone : null),
                reservation_expected_checkout: order.reservation_expected_checkout ?? (order.order_type === "RESERVATION" ? order.expected_checkout : null)
            };
        });

        result.auditLogs = logs;
        const [users] = await pool.query("SELECT * FROM users ORDER BY username");
        result.users = users.map(publicUser);
    }

    return result;
}

// ── Room actions (with transactions) ──

async function mutateRoomAction(roomId, actionType, rawGuestInfo, actor) {
    const conn = await pool.getConnection();
    try {
        await conn.beginTransaction();

        const [roomRows] = await conn.query("SELECT * FROM rooms WHERE id = ? FOR UPDATE", [roomId]);
        if (!roomRows.length) throw new Error("房间不存在");
        const room = roomRows[0];

        const guest = guestInfo(rawGuestInfo);
        const [orderRows] = await conn.query("SELECT * FROM orders WHERE room_id = ? AND status = 'ACTIVE' LIMIT 1", [room.id]);
        const currentOrder = orderRows[0] || null;

        const stamp = now();

        if (actionType === "CHECK_IN") {
            if (room.status !== "FREE") throw new Error("只有空闲房可以直接入住");
            const orderId = id();
            await conn.query(
                "INSERT INTO orders (id, room_id, guest_name, phone, expected_checkout, deposit, order_type, status, checkin_at, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                [orderId, room.id, guest.guest_name, guest.phone, guest.expected_checkout, guest.deposit, "WALK_IN", "ACTIVE", stamp, stamp, stamp]
            );
            await conn.query("UPDATE rooms SET status = 'OCCUPIED' WHERE id = ?", [room.id]);
            await conn.query(
                "INSERT INTO audit_logs (id, user, room_number, action, details, created_at) VALUES (?,?,?,?,?,?)",
                [id(), actor.username, room.room_number, "办理入住", JSON.stringify({ order_id: orderId, deposit: guest.deposit, anonymous: !guest.guest_name }), stamp]
            );
        } else if (actionType === "RESERVE") {
            if (room.status !== "FREE") throw new Error("只有空闲房可以新建预订");
            const orderId = id();
            await conn.query(
                "INSERT INTO orders (id, room_id, guest_name, phone, expected_checkout, deposit, order_type, status, reservation_at, reservation_guest_name, reservation_phone, reservation_expected_checkout, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                [orderId, room.id, guest.guest_name, guest.phone, guest.expected_checkout, guest.deposit, "RESERVATION", "ACTIVE", stamp, guest.guest_name, guest.phone, guest.expected_checkout, stamp, stamp]
            );
            await conn.query("UPDATE rooms SET status = 'RESERVED' WHERE id = ?", [room.id]);
            await conn.query(
                "INSERT INTO audit_logs (id, user, room_number, action, details, created_at) VALUES (?,?,?,?,?,?)",
                [id(), actor.username, room.room_number, "新建预订", JSON.stringify({ order_id: orderId, anonymous: !guest.guest_name }), stamp]
            );
        } else if (actionType === "CONVERT_TO_CHECK_IN") {
            if (room.status !== "RESERVED" || !currentOrder) throw new Error("没有可转入住的有效预订");
            await conn.query(
                "UPDATE orders SET guest_name = COALESCE(?, guest_name), phone = COALESCE(?, phone), expected_checkout = COALESCE(?, expected_checkout), deposit = GREATEST(?, deposit), checkin_at = ?, updated_at = ? WHERE id = ?",
                [guest.guest_name, guest.phone, guest.expected_checkout, guest.deposit || 0, stamp, stamp, currentOrder.id]
            );
            await conn.query("UPDATE rooms SET status = 'OCCUPIED' WHERE id = ?", [room.id]);
            await conn.query(
                "INSERT INTO audit_logs (id, user, room_number, action, details, created_at) VALUES (?,?,?,?,?,?)",
                [id(), actor.username, room.room_number, "预订转入住", JSON.stringify({ order_id: currentOrder.id, deposit: guest.deposit || currentOrder.deposit }), stamp]
            );
        } else if (actionType === "CANCEL_RESERVATION") {
            if (room.status !== "RESERVED" || !currentOrder) throw new Error("没有可取消的有效预订");
            await conn.query("UPDATE orders SET status = 'CANCELLED', cancelled_at = ?, updated_at = ? WHERE id = ?", [stamp, stamp, currentOrder.id]);
            await conn.query("UPDATE rooms SET status = 'FREE' WHERE id = ?", [room.id]);
            await conn.query(
                "INSERT INTO audit_logs (id, user, room_number, action, details, created_at) VALUES (?,?,?,?,?,?)",
                [id(), actor.username, room.room_number, "取消预订", JSON.stringify({ order_id: currentOrder.id }), stamp]
            );
        } else if (actionType === "CHECK_OUT") {
            if (room.status !== "OCCUPIED" || !currentOrder) throw new Error("没有可退房的有效入住客单");
            await conn.query("UPDATE orders SET status = 'COMPLETED', checkout_at = ?, updated_at = ? WHERE id = ?", [stamp, stamp, currentOrder.id]);
            await conn.query("UPDATE rooms SET status = 'MAINTENANCE' WHERE id = ?", [room.id]);
            await conn.query(
                "INSERT INTO audit_logs (id, user, room_number, action, details, created_at) VALUES (?,?,?,?,?,?)",
                [id(), actor.username, room.room_number, "退房结算", JSON.stringify({ order_id: currentOrder.id, deposit_refund: currentOrder.deposit || 0 }), stamp]
            );
        } else if (actionType === "CLEAN_DONE") {
            if (room.status !== "MAINTENANCE") throw new Error("只有维修/打扫房可以释放");
            await conn.query("UPDATE rooms SET status = 'FREE' WHERE id = ?", [room.id]);
            await conn.query(
                "INSERT INTO audit_logs (id, user, room_number, action, details, created_at) VALUES (?,?,?,?,?,?)",
                [id(), actor.username, room.room_number, "打扫完成", JSON.stringify({}), stamp]
            );
        } else {
            throw new Error("未知动作类型");
        }

        await conn.commit();
    } catch (e) {
        await conn.rollback();
        throw e;
    } finally {
        conn.release();
    }
}

// ── WebSocket ──

function broadcast(payload) {
    const frame = websocketFrame(JSON.stringify(payload));
    for (const socket of sockets) {
        if (!socket.destroyed) socket.write(frame);
    }
}

function websocketFrame(text) {
    const payload = Buffer.from(text);
    const header = [];
    header.push(0x81);
    if (payload.length < 126) {
        header.push(payload.length);
    } else if (payload.length < 65536) {
        header.push(126, (payload.length >> 8) & 255, payload.length & 255);
    } else {
        header.push(127, 0, 0, 0, 0, (payload.length >> 24) & 255, (payload.length >> 16) & 255, (payload.length >> 8) & 255, payload.length & 255);
    }
    return Buffer.concat([Buffer.from(header), payload]);
}

// ── API Router ──

async function handleApi(req, res, url) {
    try {
        const method = req.method;
        const parts = url.pathname.split("/").filter(Boolean);

        // ── Install endpoints (no auth required, only when not installed) ──
        if (method === "GET" && url.pathname === "/api/install/status") {
            return json(res, 200, { installed });
        }

        if (!installed) {
            if (method === "POST" && url.pathname === "/api/install/test-db") {
                const payload = await parseBody(req);
                const result = await db.testConnection(payload);
                if (result.ok) return json(res, 200, { ok: true });
                return json(res, 400, { error: result.error });
            }

            if (method === "POST" && url.pathname === "/api/install") {
                const payload = await parseBody(req);
                if (!payload.db || !payload.admin) return json(res, 400, { error: "缺少必要参数" });
                if (!payload.admin.username) return json(res, 400, { error: "请输入管理员用户名" });
                if (!payload.admin.password || String(payload.admin.password).length < 6) return json(res, 400, { error: "密码至少 6 位" });
                try {
                    await db.runInstall(payload.db, payload.admin);
                    installed = true;
                    pool = db.getPool();
                    sessions = await db.loadSessions();
                    await db.cleanOldLogs();
                    return json(res, 200, { ok: true });
                } catch (e) {
                    return json(res, 400, { error: "安装失败：" + e.message });
                }
            }

            // Not installed and not an install endpoint → 403
            return json(res, 403, { error: "系统未安装，请先完成安装" });
        }

        // ── All endpoints below require installed system ──

        // Auth endpoints (no login required)
        if (method === "GET" && url.pathname === "/api/auth/me") {
            const user = await currentUser(req);
            const [countRows] = await pool.query("SELECT COUNT(*) as c FROM users");
            return json(res, 200, { user: publicUser(user), needsSetup: countRows[0].c === 0 });
        }

        if (method === "POST" && url.pathname === "/api/auth/login") {
            const payload = await parseBody(req);
            const [rows] = await pool.query("SELECT * FROM users WHERE username = ?", [String(payload.username || "").trim()]);
            const user = rows[0];
            if (!user || !verifyPassword(payload.password || "", user.password_hash)) {
                return json(res, 401, { error: "账号或密码错误" });
            }
            const token = crypto.randomBytes(32).toString("hex");
            await saveSession(token, user.id);
            setCookie(res, token);
            return json(res, 200, { user: publicUser(user) });
        }

        if (method === "POST" && url.pathname === "/api/auth/logout") {
            const token = parseCookies(req).ns_session;
            if (token) await deleteSession(token);
            clearCookie(res);
            return json(res, 200, { ok: true });
        }

        // All endpoints below require login
        const actor = await requireUser(req);

        if (method === "GET" && url.pathname === "/api/inventory") {
            return json(res, 200, await inventory(actor));
        }

        if (method === "PATCH" && url.pathname === "/api/settings") {
            await requireAdmin(req);
            const settings = validateSettings({ ...await getSettings(), ...(await parseBody(req)) });
            await saveSettings(settings);
            broadcast({ type: "inventory_changed" });
            return json(res, 200, await inventory(actor));
        }

        // Users
        if (method === "POST" && url.pathname === "/api/users") {
            await requireAdmin(req);
            const payload = validateUserPayload(await parseBody(req));
            const [existing] = await pool.query("SELECT id FROM users WHERE username = ?", [payload.username]);
            if (existing.length) throw new Error("账号名称已存在");
            const userId = id();
            const stamp = now();
            await pool.query(
                "INSERT INTO users (id, username, role, password_hash, created_at, updated_at) VALUES (?,?,?,?,?,?)",
                [userId, payload.username, payload.role, passwordHash(payload.password), stamp, stamp]
            );
            const [users] = await pool.query("SELECT * FROM users ORDER BY username");
            return json(res, 201, { users: users.map(publicUser) });
        }

        if (parts[1] === "users" && parts[2]) {
            await requireAdmin(req);
            const [targetRows] = await pool.query("SELECT * FROM users WHERE id = ?", [parts[2]]);
            if (!targetRows.length) return json(res, 404, { error: "账号不存在" });
            const target = targetRows[0];

            if (method === "PATCH") {
                const payload = validateUserPayload(await parseBody(req), target);
                const [dup] = await pool.query("SELECT id FROM users WHERE username = ? AND id != ?", [payload.username, target.id]);
                if (dup.length) throw new Error("账号名称已存在");
                const [adminCount] = await pool.query("SELECT COUNT(*) as c FROM users WHERE role = 'ADMIN'");
                if (target.role === "ADMIN" && payload.role !== "ADMIN" && adminCount[0].c <= 1) throw new Error("至少保留一个管理员账号");
                const stamp = now();
                if (payload.password) {
                    await pool.query("UPDATE users SET username = ?, role = ?, password_hash = ?, updated_at = ? WHERE id = ?", [payload.username, payload.role, passwordHash(payload.password), stamp, target.id]);
                } else {
                    await pool.query("UPDATE users SET username = ?, role = ?, updated_at = ? WHERE id = ?", [payload.username, payload.role, stamp, target.id]);
                }
                const [users] = await pool.query("SELECT * FROM users ORDER BY username");
                const [curUser] = await pool.query("SELECT * FROM users WHERE id = ?", [actor.id]);
                return json(res, 200, { users: users.map(publicUser), currentUser: publicUser(curUser[0]) });
            }

            if (method === "DELETE") {
                if (target.id === actor.id) throw new Error("不能删除当前登录账号");
                const [adminCount] = await pool.query("SELECT COUNT(*) as c FROM users WHERE role = 'ADMIN'");
                if (target.role === "ADMIN" && adminCount[0].c <= 1) throw new Error("至少保留一个管理员账号");
                await pool.query("DELETE FROM users WHERE id = ?", [target.id]);
                const [users] = await pool.query("SELECT * FROM users ORDER BY username");
                return json(res, 200, { users: users.map(publicUser) });
            }
        }

        // Room types
        if (method === "POST" && url.pathname === "/api/room-types") {
            await requireAdmin(req);
            const payload = validateRoomType(await parseBody(req));
            await pool.query("INSERT INTO room_types (id, name, description, sort_order) VALUES (?,?,?,?)", [id(), payload.name, payload.description, payload.sort_order]);
            broadcast({ type: "inventory_changed" });
            return json(res, 201, await inventory(actor));
        }

        if (parts[1] === "room-types" && parts[2]) {
            await requireAdmin(req);
            const [typeRows] = await pool.query("SELECT * FROM room_types WHERE id = ?", [parts[2]]);
            if (!typeRows.length) return json(res, 404, { error: "房型不存在" });

            if (method === "PATCH") {
                const payload = validateRoomType({ ...typeRows[0], ...(await parseBody(req)) });
                await pool.query("UPDATE room_types SET name = ?, description = ?, sort_order = ? WHERE id = ?", [payload.name, payload.description, payload.sort_order, parts[2]]);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, await inventory(actor));
            }

            if (method === "DELETE") {
                const [roomCount] = await pool.query("SELECT COUNT(*) as c FROM rooms WHERE type_id = ?", [parts[2]]);
                if (roomCount[0].c > 0) throw new Error("该房型下仍有房间，不能删除");
                await pool.query("DELETE FROM room_types WHERE id = ?", [parts[2]]);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, await inventory(actor));
            }
        }

        // Rooms
        if (method === "POST" && url.pathname === "/api/rooms") {
            await requireAdmin(req);
            const payload = validateRoom(await parseBody(req));
            const [typeCheck] = await pool.query("SELECT id FROM room_types WHERE id = ?", [payload.type_id]);
            if (!typeCheck.length) throw new Error("请选择有效房型");
            const [dup] = await pool.query("SELECT id FROM rooms WHERE room_number = ?", [payload.room_number]);
            if (dup.length) throw new Error("房号已存在");
            const roomId = id();
            await pool.query("INSERT INTO rooms (id, room_number, floor, type_id, status) VALUES (?,?,?,?,?)", [roomId, payload.room_number, payload.floor, payload.type_id, "FREE"]);
            await writeLog(payload.room_number, "新增房间", { type_id: payload.type_id }, actor.username);
            broadcast({ type: "inventory_changed" });
            return json(res, 201, await inventory(actor));
        }

        if (method === "POST" && url.pathname === "/api/rooms/bulk") {
            await requireAdmin(req);
            const payload = await parseBody(req);
            const [typeCheck] = await pool.query("SELECT id FROM room_types WHERE id = ?", [payload.type_id]);
            if (!typeCheck.length) throw new Error("请选择有效房型");
            const start = Number(payload.start);
            const end = Number(payload.end);
            const floor = Number(payload.floor || String(payload.start).charAt(0));
            if (!Number.isInteger(start) || !Number.isInteger(end) || end < start) throw new Error("请输入有效的连续房号");
            const conn = await pool.getConnection();
            try {
                await conn.beginTransaction();
                for (let rn = start; rn <= end; rn += 1) {
                    const room_number = String(rn);
                    const [dup] = await conn.query("SELECT id FROM rooms WHERE room_number = ?", [room_number]);
                    if (!dup.length) {
                        const roomId = id();
                        await conn.query("INSERT INTO rooms (id, room_number, floor, type_id, status) VALUES (?,?,?,?,?)", [roomId, room_number, floor, payload.type_id, "FREE"]);
                        await conn.query(
                            "INSERT INTO audit_logs (id, user, room_number, action, details, created_at) VALUES (?,?,?,?,?,?)",
                            [id(), actor.username, room_number, "新增房间", JSON.stringify({ type_id: payload.type_id, bulk: true }), now()]
                        );
                    }
                }
                await conn.commit();
            } catch (e) {
                await conn.rollback();
                throw e;
            } finally {
                conn.release();
            }
            broadcast({ type: "inventory_changed" });
            return json(res, 201, await inventory(actor));
        }

        if (parts[1] === "rooms" && parts[2]) {
            const [roomRows] = await pool.query("SELECT * FROM rooms WHERE id = ?", [parts[2]]);
            if (!roomRows.length) return json(res, 404, { error: "房间不存在" });
            const room = roomRows[0];

            if (method === "POST" && parts[3] === "action") {
                const payload = await parseBody(req);
                await mutateRoomAction(room.id, payload.actionType, payload.guestInfo, actor);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, await inventory(actor));
            }

            if (method === "PATCH") {
                await requireAdmin(req);
                const payload = validateRoom({ ...room, ...(await parseBody(req)) });
                const [typeCheck] = await pool.query("SELECT id FROM room_types WHERE id = ?", [payload.type_id]);
                if (!typeCheck.length) throw new Error("请选择有效房型");
                const [dup] = await pool.query("SELECT id FROM rooms WHERE room_number = ? AND id != ?", [payload.room_number, room.id]);
                if (dup.length) throw new Error("房号已存在");
                await pool.query("UPDATE rooms SET room_number = ?, floor = ?, type_id = ? WHERE id = ?", [payload.room_number, payload.floor, payload.type_id, room.id]);
                await writeLog(payload.room_number, "修改房间", { type_id: payload.type_id, floor: payload.floor }, actor.username);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, await inventory(actor));
            }

            if (method === "DELETE") {
                await requireAdmin(req);
                if (STATUS.has(room.status) && room.status !== "FREE") throw new Error("只能删除空闲房间");
                await pool.query("DELETE FROM rooms WHERE id = ?", [room.id]);
                await writeLog(room.room_number, "删除房间", {}, actor.username);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, await inventory(actor));
            }
        }

        // Orders
        if (parts[1] === "orders" && parts[2]) {
            await requireAdmin(req);
            const [orderRows] = await pool.query("SELECT * FROM orders WHERE id = ?", [parts[2]]);
            if (!orderRows.length) return json(res, 404, { error: "订单不存在" });
            const order = orderRows[0];

            if (method === "DELETE") {
                if (order.status === "ACTIVE") throw new Error("不能删除进行中的订单，请先退房或取消");
                const [roomRows] = await pool.query("SELECT * FROM rooms WHERE id = ?", [order.room_id]);
                const room = roomRows[0];
                await pool.query("DELETE FROM orders WHERE id = ?", [order.id]);
                await writeLog(room?.room_number, "删除订单", { order_id: order.id, guest_name: order.guest_name }, actor.username);
                broadcast({ type: "inventory_changed" });
                return json(res, 200, await inventory(actor));
            }
        }

        json(res, 404, { error: "API 不存在" });
    } catch (err) {
        json(res, err.status || 400, { error: err.message });
    }
}

// ── Static files ──

function serveStatic(req, res, url) {
    // If not installed, serve install page for all non-API routes
    if (!installed) {
        res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
        return fs.createReadStream(path.join(root, "install.html")).pipe(res);
    }

    const filePath = url.pathname === "/" || url.pathname === "/admin"
        ? path.join(root, "index.html")
        : path.join(root, decodeURIComponent(url.pathname));
    if (!filePath.startsWith(root)) {
        res.writeHead(403);
        return res.end("Forbidden");
    }
    fs.readFile(filePath, (err, content) => {
        if (err) {
            res.writeHead(404);
            return res.end("Not found");
        }
        const ext = path.extname(filePath);
        const type = ext === ".html" ? "text/html; charset=utf-8" : "application/octet-stream";
        res.writeHead(200, { "Content-Type": type });
        res.end(content);
    });
}

// ── Server ──

const server = http.createServer((req, res) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (url.pathname.startsWith("/api/")) return handleApi(req, res, url);
    serveStatic(req, res, url);
});

server.on("upgrade", async (req, socket) => {
    if (req.url !== "/ws/rooms") return socket.destroy();
    const user = await currentUser(req);
    if (!user) return socket.destroy();
    const key = req.headers["sec-websocket-key"];
    const accept = crypto.createHash("sha1").update(`${key}258EAFA5-E914-47DA-95CA-C5AB0DC85B11`).digest("base64");
    socket.write([
        "HTTP/1.1 101 Switching Protocols",
        "Upgrade: websocket",
        "Connection: Upgrade",
        `Sec-WebSocket-Accept: ${accept}`,
        "",
        ""
    ].join("\r\n"));
    sockets.add(socket);
    socket.on("close", () => sockets.delete(socket));
    socket.on("error", () => sockets.delete(socket));
});

// ── Startup ──

async function main() {
    try {
        if (installed) {
            pool = db.initFromConfig();
            if (!pool) {
                installed = false;
            } else {
                // Test connection
                try {
                    const conn = await pool.getConnection();
                    conn.release();
                } catch (e) {
                    console.error("Database connection failed:", e.message);
                    console.error("If you need to reinstall, delete data/install.lock and data/config.json");
                    process.exit(1);
                }
                await db.cleanOldLogs();
                sessions = await db.loadSessions();
            }
        }

        if (!installed) {
            console.log("NexusStay OS is NOT installed. Opening install wizard...");
        }

        server.listen(port, () => {
            console.log(`NexusStay OS running at http://localhost:${port}`);
            if (!installed) console.log("→ Visit http://localhost:" + port + " to complete installation");
        });
    } catch (err) {
        console.error("Failed to start:", err.message);
        process.exit(1);
    }
}

main();
